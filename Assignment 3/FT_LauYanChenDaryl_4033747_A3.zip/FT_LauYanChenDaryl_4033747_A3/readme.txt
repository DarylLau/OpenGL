Name : Lau Yan Chen Daryl
Student Number: 4033747
Course : BMMF

main task and advance task all attempted.


Controls
========
[Up]     Zoom In" );
[Down]   Zoom Out" );
[Left]   Move Leftwards" );
[Right]  Move Rightwards" );
[Home]   Move Upwards" );
[End]    Move Downwards" );
[u]      Roll Left" );
[o]      Roll Right" );
[i]      Pitch Up" );
[k]      Pitch Down" );
[j]      Yaw Left" );
[l]      Yaw Right" );
[r]      Reset Camera" );    
[w]      Wire Frame Mode" );
[s]      Solid Fill Mode" );
[q]      Flat/Smooth Shading" );
[a]      Colour Tracking" );
[1]      Toggle BackLight on/off " );
[2]      Toggle FrontLight on/off" );
[3]      Toggle SpotLight on/off" );
[d]      Toggle Disco on/off" );
[z]      Decrease Swinging Speed" );
[x]      Increase Swinging Speed" );
[Esc]     Close Application" );